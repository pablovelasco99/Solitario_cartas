
package solitario.IU;

import static solitario.IU.SolitarioNuevo.inicioPartida;

/**
 *
 * @author AEDI
 */
public class Main {
    
 public static void main(String[] args) {
                inicioPartida();
           
}

    
}
